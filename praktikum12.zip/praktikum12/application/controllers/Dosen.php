<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
    public function index(){
        $this->load->model('dosen_model','dosen');

        $data['list_dosen']=$this->dosen->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/index',$data);
        $this->load->view('layout/footer');
        
    }

    public function view(){
        $_nidn = $this->input->get('id');
        $this->load->model('dosen_model','dosen');
        $data['dsn']=$this->dosen->findById($_nidn);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/view',$data);
        $this->load->view('layout/footer');
        //die("NIDN ".$_nidn);
    }

    public function create(){
        $data['judul']='Form Kelola Dosen';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("dosen_model","dosen");

        $_nidn = $this->input->post('nidn');
        $_nama= $this->input->post('nama');
        $_gender = $this->input->post('jk');
        $_tmp_lahir = $this->input->post('tmp_lahir');
        $_tgl_lahir = $this->input->post('tgl_lahir');
        $_prodi = $this->input->post('prodi');
        $_pendidikan_akhir = $this->input->post('pendidikan_akhir');
        $_idedit = $this->input->post('idedit');//hidden field

        $data_dsn[]=$_nidn;// ? 1
        $data_dsn[]=$_nama;// ? 2
        $data_dsn[]=$_gender;// ? 3
        $data_dsn[]=$_tmp_lahir;// ? 4
        $data_dsn[]=$_tgl_lahir;// ? 5
        $data_dsn[]=$_prodi;// ? 6
        $data_dsn[]=$_pendidikan_akhir;// ? 7

        if(isset($_idedit)){
            //update data lama
            $data_dsn[]=$_idedit; // ? 8
            $this->dosen->update($data_dsn);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->dosen->save($data_dsn);   
        }
        
        redirect(base_url().'index.php/dosen/view?id='.$_nidn, 'refresh');

    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("dosen_model","dosen");
        $dsnedit = $this->dosen->findById($_id);

        $data['judul']='Form Update Dosen';
        $data['dsnedit']=$dsnedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("dosen_model","dosen");
        $this->dosen->delete($_id);
        redirect(base_url().'index.php/dosen', 'refresh');
    }
    
}

//     public function index(){
//         $this->load->model('dosen_model','dsn1');
//         $this->dsn1->id=1;
//         $this->dsn1->nidn='0414047101';
//         $this->dsn1->nama='Sirojul Munir, S.Si, M.Kom.';
//         $this->dsn1->gender='L';
//         $this->dsn1->pendidikan='S2';


//         $this->load->model('dosen_model','dsn2');
//         $this->dsn2->id=2;
//         $this->dsn2->nidn='0413128601';
//         $this->dsn2->nama='Ahmad Rio Adriansyah, S.Si. M.Si';
//         $this->dsn2->gender='L';
//         $this->dsn2->pendidikan='S2';

//         $this->load->model('dosen_model','dsn3');
//         $this->dsn3->id=3;
//         $this->dsn3->nidn='402018701';
//         $this->dsn3->nama='Amalia Rahmah, S.T, M.T';
//         $this->dsn3->gender='P';
//         $this->dsn3->pendidikan='S2';
        
//         $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
//         $data['list_dsn']=$list_dsn;
//         $this->load->view('layout/header');
//         $this->load->view('layout/sidebar');
//         $this->load->view('dosen/index',$data);
//         $this->load->view('layout/footer');


//     }

//     public function create(){
//         $data['judul']='Form Kelola Dosen';
//         $this->load->view('layout/header');
//         $this->load->view('layout/sidebar');
//         $this->load->view('dosen/create',$data);
//         $this->load->view('layout/footer');
//     }

//     public function save(){
//        $this->load->model("dosen_model","dsn1");

//        $this->dsn1->nidn = $this->input->post('nidn');
//        $this->dsn1->nama = $this->input->post('nama');
//        $this->dsn1->gender = $this->input->post('jk');
//        $this->dsn1->tmp_lahir = $this->input->post('tmp_lahir');
//        $this->dsn1->tgl_lahir = $this->input->post('tgl_lahir');
//        $this->dsn1->pendidikan = $this->input->post('pendidikan');
//        $this->dsn1->prodi = $this->input->post('prodi');

//        $data['dsn1'] = $this->dsn1;
//        $this->load->view('layout/header');
//        $this->load->view('layout/sidebar');
//        $this->load->view('dosen/view',$data);
//        $this->load->view('layout/footer');
//     }


// }